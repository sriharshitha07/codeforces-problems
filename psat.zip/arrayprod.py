def prod(l):
	if len(l) == 1:
		return l[0]
	else:
		return l[len(l)-1]+prod(l[:len(l)-1])