def sw(l,i,j):
    temp = l[i]
    l[i] = l[j]
    l[j] = temp

def bsort(li,n):
    for i in range(n-1):
        if li[i] > li[i+1]:
            sw(li,i,i+1)
    if n-1>1:
        bsort(li,n-1)

A = list(input().split())
bsort(A,len(A))
print(A)