def cons(s):
    if s == "":
        return 0
    elif s[0] not in "aeiouAEIOU":
        return 1 + cons(s[1:])
    else:
        return 0 + cons(s[1:])
print(cons("karan"))
